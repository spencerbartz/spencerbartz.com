#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <errno.h>

void println(char* str, ...)
{
  printf("%s\n", str);
}

char* build_prefix(int length, char * prefix)
{
  char* divider = (char*)calloc(length * strlen(prefix), sizeof(char));

  while(length > 0)
  {
    strncat(divider, prefix, strlen(prefix));
    length = length - 1;
  }

  return divider;
}

void list_files(char* dir_name, int level)
{
  //Print current directory and list all its files
  DIR* d = opendir(dir_name);
  //printf("dir_name: %s\n", dir_name);
  while(1)
  {
    struct dirent* entry;
    entry = readdir(d);

    if(!entry)
    {
      //fprintf (stderr, "Cannot read from directory '%s': %s : level %d\n", dir_name, strerror (errno), level);
      break;
    }

    //printf("FULL PATH %s\n", full_path_dir_name);

    //check if the entry is a directory (don't need full path)
    if(strcmp(entry->d_name, ".") && strcmp(entry->d_name, ".."))
    {
      char * full_path_dir_name = (char*)calloc(strlen(dir_name) + strlen(entry->d_name), sizeof(char));
      strncat(full_path_dir_name, dir_name, strlen(dir_name));
      strncat(full_path_dir_name, "/", 1);
      strncat(full_path_dir_name, entry->d_name, strlen(entry->d_name));

      struct stat buf;

      if(stat(full_path_dir_name, &buf) == 0 && S_ISDIR(buf.st_mode))
      {
        printf("%s%s\n", build_prefix(level, "--"), entry->d_name);
        list_files(full_path_dir_name, level + 1);
      }
      else
      {
        printf("%s", build_prefix(level, "  "));
        println(entry->d_name);
      }
    }
  }

  closedir(d);
}

int main(int argc, char** argv)
{
  char cwd[1024];

  if(getcwd(cwd, sizeof(cwd)) != NULL)
  {
    list_files(cwd, 1);
  }

  return 0;
}
