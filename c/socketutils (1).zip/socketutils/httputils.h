#ifndef HTTPUTILS_H
#define HTTPUTILS_H

#define MAX_REQUEST 5096

//Function prototypes
char * getHttpResponse(const char * host, const char * client);

#endif
