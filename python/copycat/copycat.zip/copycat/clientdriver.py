import getopt
import sys

from CopyCat import Client
from CopyCat import KennyLogger

def print_usage():
    print("Example Usage: python clientdriver.py --file somefile.txt --ip 127.0.0.1 --port 8181")
    sys.exit(0)

def main():
    user_file = None
    server_ip = None
    server_port = None

    kennyLogger = KennyLogger.KennyLogger()
    kennyLogger.initialize("clientlogs")
   
    # parse command line options
    try:
        opts, args = getopt.getopt(sys.argv[1:], "hf:i:p:", ["help", "file=", "ip=", "port="])
    except getopt.GetOptError as msg:
        print(msg)
        print("for help use --help")
        sys.exit(2)
        
    # process options
    for o, a in opts:
        if o in ("-h", "--help", "-help"):
            print_usage()
        elif o in ("-f", "--file", "-file"):
            user_file = a
        elif o in ("-i", "--ip", "-ip"):
            server_ip = str(a)
        elif o in ("-p", "--port", "-port"):
            server_port = int(a)

    # Verify user entered the args correctly
    if not user_file or not server_ip or not server_port:
        print_usage()

    # Create client and try to connect to server with given data
    client = Client.Client()
    try:
        client.connect(server_ip, server_port)
    except ConnectionRefusedError:
        print("The server at <", server_ip, "> on port <", server_port, "> is not running.")
        kennyLogger.error("Failed to connect to server. IP: " + server_ip + " port: " + str(server_port))
        sys.exit(1)
        
    # read / send files
    client.openFiles(user_file)
    client.readFiles()
    client.sendFiles()
    print("File sent succesfully. Have a nice day")
    exit(0)

if __name__ == "__main__":
    main()