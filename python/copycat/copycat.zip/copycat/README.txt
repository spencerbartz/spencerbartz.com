Welcome to Copy Cat 1.0

This is a command line client / server application that allows 
users to transfer files from one machine to another.

SERVER
====================================================================
To see all the options, open a terminal or command prompt and type

$python serverdriver.py

An example invocation might look like this:

$python --savefolder path/to/folder/ --port 8000

This will start the server running on port 8000 listening for connections.
When it receives a client connection it will begin downloading the data
sent by the client and saving it in file specified by the --savefolder flag.


CLIENT
====================================================================
To see all the options, open a terminal or command prompt and type

$python clientdriver.py --help